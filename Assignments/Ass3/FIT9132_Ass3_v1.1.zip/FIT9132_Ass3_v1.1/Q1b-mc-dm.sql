/* FIT9132 2019 S2 Assignment 3 Q1-Part B ANSWERS

   Student Name:
    Student ID:

   Comments to your marker:
   
*/

/* (i)*/






/* (ii)*/








/* (iii)*/







      
/* (iv)*/










